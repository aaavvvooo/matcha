# Handoff: Matcha v2 — Dating Web App

## Overview
Matcha is a dating web application that connects users based on proximity, shared interests, and compatibility. This document describes the full UI for a React frontend implementation, covering all screens from the public landing page through authenticated in-app flows.

## About the Design Files
The files in this bundle are **high-fidelity design references built in HTML/React**. They are prototypes showing the intended look, feel, and behavior of the app — not production code to copy directly. Your task is to **recreate these designs in a proper React codebase** (e.g. Next.js or Vite + React Router) using established patterns, a real router, real API calls, and your chosen component library.

The prototype uses inline React + Babel for rapid design iteration. In production you should split each screen into its own component file, replace mock data with API calls, and use a proper state management solution (Zustand, Redux, React Query, etc.).

## Fidelity
**High-fidelity.** The prototype has final colors, typography, spacing, interactions, animations, and copy. Recreate pixel-accurately using the design tokens below.

---

## Design Tokens

### Colors
```css
--cream:   #fdf6ed   /* main background */
--cream2:  #f7ede0   /* secondary background */
--cream3:  #eeddd0   /* tertiary background, card borders */
--sand:    #e8d4bc   /* borders, dividers */
--clay:    #d4a882   /* muted accents */
--spice:   #c2784a   /* PRIMARY accent — buttons, highlights */
--spice2:  #a85e32   /* primary accent dark */
--matcha:  #6b8f5e   /* secondary accent — like button, match state */
--matcha2: #4e6e43   /* secondary accent dark */
--rose:    #e07a7a   /* notification badge, error states */
--ink:     #2c2016   /* primary text */
--ink2:    #4a3828   /* secondary text */
--ink3:    #7a6555   /* tertiary text */
--ink4:    #a8978a   /* placeholder, muted text */
--white:   #fffdf9   /* card surfaces */
```

### Typography
```
Display / Headings:  Playfair Display, serif — italic, weights 400/600/700
Body / UI:           DM Sans, sans-serif — weights 300/400/500

Font scale:
  72px  — Hero title (landing)
  56px  — Section hero
  36px  — Section heading
  32px  — Screen heading (onboarding, profile)
  30px  — Card name
  26px  — Sub-heading
  22px  — Nav title, card title
  20px  — List item title
  17px  — Feature title, body large
  15px  — Body, button
  14px  — Body small, message text
  13px  — Label, caption
  12px  — Tag, meta
  11px  — Badge, timestamp
  10px  — Section label (ALL CAPS, letter-spacing: 0.08em)
```

### Spacing
```
4px   — xs
8px   — sm
12px  — md
16px  — lg
20px  — xl
24px  — 2xl
32px  — 3xl
40px  — 4xl
48px  — 5xl
```

### Border Radius
```
4px   — pill tag inner
12px  — small card element (--r-sm)
18px  — standard card/input (--r-md)
24px  — large card
28px  — large container (--r-lg)
40px  — XL container (--r-xl)
9999px — pill / full round (--r-full)
```

### Shadows
```
--shadow-sm: 0 2px 8px rgba(44,32,22,0.08)
--shadow-md: 0 6px 24px rgba(44,32,22,0.12)
--shadow-lg: 0 16px 48px rgba(44,32,22,0.16)
```

### Animations
```
fadeUp:    opacity 0→1 + translateY 16px→0, 0.4s ease
fadeIn:    opacity 0→1, 0.25s ease
scaleIn:   opacity 0→1 + scale 0.92→1, 0.3s ease
float:     translateY 0→-7px→0, 3s ease-in-out infinite
wiggle:    rotate -4→0→4→0deg, 0.5s ease-in-out infinite
blink:     scaleY 1→0.1→1, 3.5s ease-in-out infinite
pulse:     opacity + scale, 1.2s ease-in-out infinite (typing indicator dots)
steam:     opacity 0→0.7→0 + translateY 0→-14px, 2s ease-in-out infinite
```

---

## Screens & Components

### 1. Landing Page (`/`)
**Purpose:** Public marketing page. Converts visitors to sign-ups.

**Layout:** Full-width, scrollable. Sticky top navbar. Sections stacked vertically.

**Navbar** (sticky, `--white` bg, `1.5px solid --cream3` border-bottom):
- Left: Mascot cup (32px) + "Matcha" in Playfair italic 26px bold
- Right: Ghost "Sign in" button + Primary "Get started" button

**Hero section** (padding 80px 40px, `--cream` bg):
- Left column (max-width 480px):
  - Pill badge: italic "Because love, too, can be industrialized. ✦", `--cream2` bg, `--sand` border
  - H1: "Find people worth your time." — Playfair italic 56px bold, `--ink`, "time." in `--spice`
  - Body: 17px `--ink3`, line-height 1.7
  - CTA row: Primary "Create free account" + Secondary "Sign in →" buttons
  - Stats row: 3 stat items (2,847 members / 94% find a match / 12 min avg reply time) — Playfair italic 28px bold value + 12px `--ink4` label
- Right column: 3 floating profile preview cards, rotated/offset, `--shadow-lg`

**"How it works" section** (`--white` bg, padding 60px 40px):
- Centered header: Mascot (56px, floating animation) + Playfair italic 36px heading
- 4 feature cards in a row (200px each, `--cream` bg, `--sand` border):
  - Large italic step number in `--spice` at 40% opacity
  - Playfair italic 17px title
  - 13px `--ink3` body

**CTA section** (`--cream2` bg):
- Centered heading + subtext + primary button

**Footer** (`--white` bg):
- Left: mascot + "Matcha" logo
- Right: copyright text

---

### 2. Auth Screen (`/auth`)
**Sub-modes:** landing → login | register

**Auth Landing:**
- `--cream` bg, flex column, centered
- Mascot (64px, love mood, floating animation) + "Matcha" title 72px Playfair italic
- Italic tagline in `--ink3`
- 3 floating preview cards (same as landing hero)
- CTA: "Create account" primary + "Sign in" secondary buttons
- Footer stat: "2,847 members · 94% find a match"

**Login form:**
- Back arrow + mascot (28px) + "Welcome back" heading
- Email input + Password input
- "Sign in" primary button
- "Forgot password?" link in `--spice`
- "Register" link at bottom

**Register form (3 steps):**
- Step 1: First name + Last name inputs
- Step 2: Username + Email inputs  
- Step 3: Password input
- Progress dots (active: 24px wide, inactive: 8px, `--spice` color)
- Step indicator: "1 OF 3" in `--ink4` caps
- Playfair italic 30px step title
- Continue / Create account button

**Input component:**
```
padding: 13px 16px
border-radius: --r-sm (12px)
background: --white
border: 1.5px solid --sand
color: --ink
font-size: 15px
focus: outline 2px solid --spice
```

---

### 3. Onboarding (`/onboarding`) — 4 steps
**Purpose:** First-time profile setup after registration.

Steps: Identity → Preferences → Your story → Interests

**Layout:** Full height flex column. Sticky header with logo + progress dots. Scrollable content area. Fixed footer with Back/Continue buttons.

**Step 1 — Gender (single select):**
- 4 options: Man / Woman / Non-binary / Other
- Button style: full-width, `padding: 15px 20px`, `border-radius: --r-md`
- Selected: `--spice` bg + white text + "✓" checkmark
- Unselected: `--white` bg + `--sand` border

**Step 2 — Preferences (multi select):**
- 3 options: Men / Women / Everyone
- Same button style as Step 1
- Hint text: "Select all that apply" in `--ink4`

**Step 3 — Bio:**
- Textarea, 5 rows, max 300 chars
- Character counter bottom-right, turns `--rose` above 260
- Tip box: `--cream2` bg, `--sand` border, italic 12px hint

**Step 4 — Interest tags:**
- Pill chips in wrapping flex
- Selected: `--spice` bg + white
- Unselected: `--white` bg + `--sand` border

---

### 4. Discovery (`/discover`)
**Purpose:** Main browse screen. Two-column layout on desktop.

**Top bar:** Mascot logo + Sort chips (proximity/fame/tags) + 🔔 notification bell with badge

**Left column (max-width 420px, `--cream` bg):**

*Card Stack:*
- Ghost card behind: 95% scale, translateY 14px, 45% opacity
- Main card: white, border-radius 24px, `--shadow-lg`, draggable
  - Photo area (200px): gradient placeholder, avatar centered
  - Like stamp (drag right >40px): "Like ✦" rotated -8deg, `--matcha` border
  - Pass stamp (drag left >40px): "Pass" rotated 8deg, `--clay` border
  - Online badge + "liked you" badge (if applicable)
  - Info: name/age italic, distance, bio (12px), tags (pill chips)
  - Action row: Pass (secondary) + ··· (ghost, opens right panel) + Like ✦ (matcha)
- Hint text: "X people nearby · drag or tap ···"
- "Coming up" strip: small cards for next 3 profiles

*Empty state:* Sleepy mascot + "That's everyone for now." message

**Right column (flex:1, `--cream2` bg):**
- Profile detail panel, updates when card is tapped
- Hero: 220px gradient with large avatar
- Name/age/city/distance + fame meter (SVG circle)
- "About" card: white bg, `--cream3` border
- Interests tags
- Shared interests banner (green): "✦ N shared interests: ..."
- Actions: "Full profile" secondary + "Like ✦" matcha buttons
- Empty state: "← Select a profile to preview" centered, 50% opacity

**Match overlay (full-screen):**
- `rgba(107,143,94,.95)` bg
- Excited mascot (wiggle animation)
- "It's a match!" Playfair italic 36px white
- "Send a message →" white button
- "Keep browsing" ghost button

**Card drag mechanics:**
- `transform: translateX(dx) translateY(dy*.15) rotate(dx*.035deg)`
- Opacity: `max(0.4, 1 - abs(dx)/260)`
- Threshold: 70px to trigger action
- Spring back: cubic-bezier(.34,1.56,.64,1) 0.35s

---

### 5. Search (`/search`)
**Purpose:** Advanced profile search with filters.

**Filters panel:**
- Age range: two number inputs (min/max) in a row
- Fame rating: range slider with `accentColor: --spice` + live value display
- Location: text input
- Interest tags: pill chip multi-select

**Results list:** Profile cards (avatar + name/age/city/tags + fame meter), tappable → profile view

---

### 6. Matches (`/matches`)
**Purpose:** Tabs for chats and notifications.

**Tab bar:** "Chats" | "Notifications (N)" — pill toggle buttons

**Chats tab:** List of matched users
- Avatar (52px, online indicator) + name Playfair italic + last message preview (truncated) + timestamp
- Unread: `--cream2` bg, `--spice` dot indicator, bold preview text
- Tap → opens Chat screen

**Notifications tab:**
- Item types: like (✦) / view (👁) / match (🎉) / message (💬) / unlike (💔)
- Unread: `--cream2` bg, `--spice` icon bg, `--spice` dot
- Read: transparent bg, `--cream3` icon bg
- Bold name + action text + timestamp

---

### 7. Chat List (`/messages`)
**Purpose:** All active conversations.

**Header:** "Messages" title + subtitle

**Conversation rows:**
- Avatar (52px) + name Playfair italic + last message (me: "You: ...") + time
- Unread: `--sand` border, `--spice` dot, bold text
- No unread: `--cream3` border, normal weight

**Empty state:** Shy mascot + hint text

---

### 8. Chat (`/messages/:userId`)
**Purpose:** Real-time 1:1 messaging between connected users.

**Header:** Back arrow + avatar (42px) + name/online status + fame meter

**Messages:**
- Own messages: `--spice` bubble, `border-radius: 18px 18px 4px 18px`, white text
- Their messages: `--white` bubble, `--cream3` border, `border-radius: 18px 18px 18px 4px`
- Max-width: 74%
- Timestamp: 10px, right-aligned, 60% opacity for own
- Typing indicator: 3 dots, `--clay` color, `pulse` animation

**Matched divider:** "You matched — say something real." italic centered text

**Input bar:** `--white` bg, pill input (`--cream` bg) + round send button (`--spice` when has text)

---

### 9. Profile View (`/profile/:userId`)
**Purpose:** Full profile of another user.

**Top bar:** Back arrow + Report (ghost) + Block (danger) buttons

**Hero:** 200px gradient + large avatar (88px) + online status badge

**Info section:**
- Name Playfair italic 30px + age/city/distance
- Fame meter (large, 32px radius)
- "Already liked you" banner: `#fff5ee` bg, `--clay` border, `--spice2` text
- "About" card + interests tags
- Visit history note (12px italic `--ink4`)
- Like button (toggles to filled) + Message button (appears after mutual like)

**Block confirmation:** Full-screen empty state with mascot

---

### 10. Profile Edit (`/profile/edit`)
**Purpose:** User's own profile management.

**Sections (each in white card, `--cream3` border):**
1. Avatar + name + city + fame meter (activity summary)
2. Photo slots (5 slots, 52×52px, dashed border)
3. First/Last name + Username + Email inputs
4. Gender (single-select chips) + Interested in (single-select chips)
5. Bio textarea (300 char limit)
6. Interest tags (multi-select chips)
7. Location input
8. Activity stats: "12 viewed you" + "8 liked you" (Playfair italic 26px spice numbers)

**Save button:** Full-width primary, shows "✓ Saved!" for 2s on click

---

## Mascot: MatchaCup Component
A plastic takeaway matcha cup with dome lid, straw, trapezoid body, sleeve band, and animated face.

**Props:**
```ts
interface MatchaCupProps {
  size?: number      // width in px, height auto-scales (ratio 80:110)
  mood?: 'happy' | 'shy' | 'excited' | 'sleepy' | 'love'
  animate?: boolean  // enables steam/blink/zzz animations
  style?: CSSProperties
}
```

**Mood guide:**
- `happy` — arc eyes (^‿^), simple smile
- `shy` — arc eyes + blush cheeks
- `excited` — dot eyes with shine, open mouth
- `sleepy` — flat line eyes + zzz floating
- `love` — heart eyes

**Placement:**
- Landing navbar: size=32, mood=happy, animate=false
- Landing hero: size=64, mood=love, animate=true + float animation
- "How it works": size=56, mood=happy, animate=true + float animation
- Discovery topbar: size=30, mood=happy, animate=false
- Empty discovery state: size=80, mood=sleepy, animate=true
- Match overlay: size=100, mood=excited, wiggle animation
- Chat list empty: size=56, mood=shy, animate=true
- Profile edit header: size=28, mood=happy, animate=false
- Onboarding header: size=26, mood=happy, animate=false

---

## Navigation Structure
```
/ (landing)
  /auth
    /auth?mode=login
    /auth?mode=register
  /onboarding (protected, first-time only)
  /app (protected)
    /discover        ← default
    /search
    /matches
    /messages
    /messages/:id    ← chat
    /profile/:id     ← view another user
    /profile/edit    ← own profile
```

**Bottom navigation tabs (in-app):**
- ◎ Discover → `/discover`
- ⊙ Search → `/search`
- ♡ Matches → `/matches` (notification badge)
- ✉ Chat → `/messages`
- ◉ Profile → `/profile/edit`

---

## State Requirements

### Auth state
```ts
type AuthState = 'landing' | 'auth' | 'onboarding' | 'app'
```

### User profile
```ts
interface Profile {
  id: number
  name: string
  age: number
  city: string
  bio: string
  tags: string[]
  fame: number       // 0-100
  distance: number   // km
  online: boolean
  lastSeen?: string
  liked: boolean     // has this user liked the current user?
  photos: number     // count of uploaded photos
}
```

### Notifications
```ts
interface Notification {
  id: number
  type: 'like' | 'view' | 'match' | 'message' | 'unlike'
  name: string
  text: string
  time: string
  read: boolean
}
```

### Real-time requirements
Per the spec, notifications and chat messages must update with **max 10 second delay**. Recommended: WebSocket connection (socket.io or native WS) established on login, maintained throughout session.

---

## Security Notes (from spec)
- Never store plain-text passwords — use bcrypt
- Protect against SQL injection (use parameterized queries)
- Validate all form inputs client AND server side
- Restrict file uploads (images only, max size)
- All credentials in `.env`, never committed to git
- GPS location requires explicit user consent (GDPR)

---

## Files in This Bundle
- `README.md` — this document
- `Matcha v2.html` — full hi-fi prototype (all screens, interactive)
- `tokens.css` — design tokens as CSS custom properties

---

## Recommended Tech Stack
```
Frontend:   Next.js 14 (App Router) or Vite + React Router
Styling:    CSS Modules or Tailwind CSS (map tokens below)
State:      Zustand (lightweight) or React Query for server state
Realtime:   Socket.io client
Auth:       JWT stored in httpOnly cookie
```
